import os
if os.path.exists('C:\\Users\\adija\\facerecognition\\collection') :
    print("Yes")
else :
    print("No")